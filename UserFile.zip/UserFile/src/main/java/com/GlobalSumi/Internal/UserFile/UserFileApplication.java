package com.GlobalSumi.Internal.UserFile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserFileApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserFileApplication.class, args);
	}

}
