package com.GlobalSumi.Internal.UserFile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserFileApplicationTests {

	@Test
	void contextLoads() {
	}

}
